import React, { Component } from "react";

/* Import Components */
import Input from "../components/Input";
import Select from "../components/Select";
import Button from "../components/Button";
import "../styles/insubuyForm.scss";

class FormContainer extends Component {
  constructor(props) {
    super(props);

    this.state = {
      quote: {
        age: "",
        policyMaximumOptions: "",
        citizenship: "",
        mailingState: ""
      },

      policyMaximumOptions: [
        { label: "50,000", value: "50" },
        { label: "100,000", value: "100" },
        { label: "250,000", value: "250" },
        { label: "500,000", value: "500" }
      ],
      skillOptions: ["Programming", "Development", "Design", "Testing"]
    };
    this.handleAge = this.handleAge.bind(this);
    this.handleFormSubmit = this.handleFormSubmit.bind(this);
    this.handleClearForm = this.handleClearForm.bind(this);
    this.handleInput = this.handleInput.bind(this);
  }

  handleAge(e) {
    let value = e.target.value;
    this.setState(
      prevState => ({
        quote: {
          ...prevState.quote,
          age: value
        }
      }),
      () => console.log(this.state.quote)
    );
  }

  handleInput(e) {
    let value = e.target.value;
    let name = e.target.name;
    this.setState(
      prevState => ({
        quote: {
          ...prevState.quote,
          [name]: value
        }
      }),
      () => console.log(this.state.quote)
    );
  }

  handleFormSubmit(e) {
    e.preventDefault();
    let quote = this.state.quote;

    fetch("http://localhost:8080/quotes", {
      method: "POST",
      body: JSON.stringify(quote),
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    }).then(response => {
      response.json().then(data => {
        console.log("Successful" + data);
      });
    });
  }

  handleClearForm(e) {
    e.preventDefault();
    this.setState({
      quote: {
        age: "",
        policyMaximumOptions: "",
        citizenship: "",
        mailingState: ""
      }
    });
  }

  render() {
    return (
      <div className="insubuy-form">
        <form className="container-fluid" onSubmit={this.handleFormSubmit}>
          <Select
            title={"Policy Maximum"}
            name={"policyMax"}
            options={this.state.policyMaximumOptions}
            value={this.state.quote.policyMaximumOptions}
            placeholder={"Choose your policy maximum"}
            handleChange={this.handleInput}
          />{" "}
          <Input
            inputtype={"text"}
            title={"Age"}
            name={"age"}
            value={this.state.quote.age}
            placeholder={"Choose your age"}
            handleChange={this.handleInput}
          />{" "}
          <Input
            inputtype={"text"}
            name={"citizenShip"}
            title={"Citizenship"}
            value={this.state.quote.citizenship}
            placeholder={"Choose your contry of citizenship"}
            handleChange={this.handleAge}
          />{" "}
          <Input
            inputtype={"text"}
            name={"age"}
            title={"Mailing State"}
            value={this.state.quote.mailingState}
            placeholder={"Enter your age"}
            handleChange={this.handleAge}
          />{" "}
          <Button
            action={this.handleFormSubmit}
            type={"orange"}
            title={"Submit"}
            style={buttonStyle}
          />{" "}
          <Button
            action={this.handleClearForm}
            type={"link"}
            title={"Clear"}
            style={buttonStyle}
          />{" "}
        </form>
      </div>
    );
  }
}

const buttonStyle = {
  margin: "10px 10px 10px 10px"
};

export default FormContainer;
